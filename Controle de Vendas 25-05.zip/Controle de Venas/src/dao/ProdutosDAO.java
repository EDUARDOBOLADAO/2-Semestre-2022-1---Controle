/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import jdbc.ConnectorFactory;
import modelo.Produtos;

/**
 *
 * @author Geral
 */
public class ProdutosDAO {

    private Connection con;

    public ProdutosDAO() {
        this.con = new ConnectorFactory().getConnection();
    }
    
    
    //Metodo Cadastrar Produtos
public void cadastrar(Produtos obj) {
try {

String sql = "insert into tb_produtos (descricao, preco,qtd_estoque,for_id) values (?,?,?,?)";
//2 passo - conectar o banco de dados e organizar o comando sql
PreparedStatement stmt = con.prepareStatement(sql);
stmt.setString(1, obj.getDescricao());
stmt.setDouble(2, obj.getPreco());
stmt.setInt(3, obj.getQtd_estoque());

stmt.setInt(4, obj.getFornecedor().getId());

stmt.execute();
stmt.close();

JOptionPane.showMessageDialog(null, "Produto Cadastrado com Sucesso!");

} catch (Exception erro) {

JOptionPane.showMessageDialog(null, "Erro : " + erro);

}

}

    public Produtos buscaPorCodigo(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
